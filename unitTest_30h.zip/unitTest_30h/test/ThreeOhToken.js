const { expect } = require('chai');
//const { ethers } = require("hardhat");
//const { ethers } = require('ethers');
 
let demoToken;
let owner;// = "0x54c3ecf2aBBD2e48869619742690327fA492DB1f";
let addr1;// = "0x08af9fa599df374c2aE6F354Cd02027d86bd8eD0";
let addr2;// = "0x8c2b9Bd235BF5d2eb968c08b9fBac367D3D4a616";
let addr3;// = "0x08af9fa599df374c2aE6F354Cd02027d86bd8eD0";
let addr4;
let addr5;// = "0x08af9fa599df374c2aE6F354Cd02027d86bd8eD0";
let addr6;
let addrs;

 
// Start test block
describe('3OHT', () => {
  

  beforeEach(async () => {
    
    [owner, addr1, addr2, addr3, addr4, addr5, addr6, ...addrs] = await ethers.getSigners();
    console.log("Deploying contracts with the account:", owner.address, addr3.address, addr4.address, addr5.address,  addr6.address);    
    console.log("Account balance:", (await owner.getBalance()).toString());
    const DemoToken = await ethers.getContractFactory("ThreeOhToken");
    demoToken = await DemoToken.deploy();
    console.log("Contract deployed at:", demoToken.address);
    

  });
   
 /*  it("Should should successfully deploy and balance and supply check", async () => {
    
    console.log("success!");
    const ownerBalance=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance"+ownerBalance);  
    let totalSupply=await demoToken.totalSupply();
    console.log("TSUP"+totalSupply.toString());
    expect(totalSupply.toString()).to.equal(ownerBalance.toString());
  });

  it("Should transfer tokens between accounts", async () => {

    await demoToken.transfer(addr1.address, 100);
    const addr1Bal = await demoToken.balanceOf(addr1.address);
    expect(addr1Bal).to.equal(100);
  });/*

  it("shold allow other account to spent amount", async () =>{
    const appr = await demoToken.approve(addr1.address,100000);
    const allowAmt = await demoToken.allowance( owner.address, addr1.address);
    console.log("allowence amount",allowAmt.toString());
    expect(allowAmt).to.equal(100000);
    
  });*/

  it("shold allow transfer other Accounts", async function() {

    const ownerBalance=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance"+ownerBalance); 
    const appr = await demoToken.approve(addr1.address,100000);
    const allowAmtBefore = await demoToken.allowance( owner.address, addr1.address);
    console.log("allowence amount Before",allowAmtBefore.toString());
    const status = await demoToken.connect(addr1).transferFrom(owner.address, addr2.address,1000);
    const ownerBalanceAftertx=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance After"+ownerBalanceAftertx); 
    const allowAmt = await demoToken.allowance( owner.address, addr1.address);
    console.log("allowence amount After",allowAmt.toString());
    expect(allowAmt).to.equal(allowAmtBefore-1000);
    expect(ownerBalanceAftertx.toString()).to.equal("2099999999999999999000");
    
  }); /*

  it("should validate total fees", async function (){

    const fee = await demoToken.totalFees();
    console.log("fee is before", fee);
    const deliver = await demoToken.deliver(100);
    const feeAf = await demoToken.totalFees();
    console.log("fee is After", feeAf);
    
  });

  it("should validate minting", async function(){

    const ownerBalance=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance"+ownerBalance); 
    await demoToken._mint(1111111111111);
    const ownerBalance1=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance"+ownerBalance1); 
    expect(ownerBalance1.toString()).to.equal("2100000001111111111111");
  });

  it("should validate initail Token distribution!", async function(){
     const Bal = await demoToken.balanceOf(owner.address);
    console.log("Bal    ",Bal);
    console.log("sending to exchange wallet  ",addr3.address);
    console.log("sending to Marketing and dev wallet  ",addr4.address);
    await demoToken.transfer(addr3.address,  "850000000000000000000");
    await demoToken.transfer(addr4.address,  "50000000000000000000");
    await demoToken.transfer("0x000000000000000000000000000000000000dEaD",  "400000000000000000000");
    const supply = await demoToken.totalSupply();
    console.log("supply    ",supply);
    console.log("After 1st transfer  ");
    const Bal1 = await demoToken.balanceOf(owner.address);
    const Bal2 = await demoToken.balanceOf(addr3.address);
    const Bal3 = await demoToken.balanceOf(addr4.address);
    console.log("Primary Wallet balance    ",Bal1); 
    console.log("exchange Wallet balance    ",Bal2); 
    console.log("Marketing and dev wallet balance    ",Bal3); 
    const Bal4 = await demoToken.balanceOf("0x000000000000000000000000000000000000dead");
    console.log("dead wallet balance    ",Bal4);
  })
  
  it("should validate tokenomics transfer", async function() {

    const ownerBalance=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance"+ownerBalance); 
    const add1Balance=await demoToken.connect(addr1).balanceOf(addr1.address);   
    console.log("add1 Balance"+add1Balance); 
    const add2Balance=await demoToken.connect(addr2).balanceOf(addr2.address);   
    console.log("add2 Balance"+add2Balance); 
    await demoToken.transfer(addr1.address,100);
    await demoToken.transfer(addr2.address,100);
    const add1Balanceup=await demoToken.connect(addr1).balanceOf(addr1.address);   
    console.log("add1 Balance up "+add1Balanceup); 
    const add2Balanceup=await demoToken.connect(addr2).balanceOf(addr2.address);   
    console.log("add2 Balance up "+add2Balanceup);
    await demoToken.connect(addr1).transfer(addr2.address,100);
    const add1Balanceupup=await demoToken.connect(addr1).balanceOf(addr1.address);   
    console.log("add1 Balance upup "+add1Balanceupup); 
    const add2Balanceupup=await demoToken.connect(addr2).balanceOf(addr2.address);   
    console.log("add2 Balance upup "+add2Balanceupup);

    const add3=await demoToken.connect(addr3).balanceOf(addr3.address);   
    console.log("add3 Balance upup "+add3); 
    const add4=await demoToken.connect(addr4).balanceOf(addr4.address);   
    console.log("MarketingAddress Balance upup "+add4);
    const add5=await demoToken.connect(addr5).balanceOf(addr5.address);   
    console.log("BuybackAddress Balance upup "+add5); 
    const add6=await demoToken.connect(addr6).balanceOf(addr6.address);   
    console.log("AdvocacyAddress Balance upup "+add6);
    
  });  */
  
});