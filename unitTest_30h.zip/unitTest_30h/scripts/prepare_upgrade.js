async function main() {
    const proxyAddress = '0x11B9f88A06d0766a97d5822194d65444bbA3AF91';
   
    const ThreeOhToken_2 = await ethers.getContractFactory("ThreeOhToken_2");
    console.log("Preparing upgrade...");
    const threeOhToken_2_Add = await upgrades.prepareUpgrade(proxyAddress, ThreeOhToken_2);
    console.log("3OHO at:", threeOhToken_2_Add);
  }
   
  main()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    });