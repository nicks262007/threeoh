const { expect } = require('chai');
//const { ethers } = require("hardhat");
//const { ethers } = require('ethers');
 
let demoToken;
let owner;// = "0x54c3ecf2aBBD2e48869619742690327fA492DB1f";
let addr1;// = "0x08af9fa599df374c2aE6F354Cd02027d86bd8eD0";
let addr2;// = "0x8c2b9Bd235BF5d2eb968c08b9fBac367D3D4a616";
let addrs;

 

describe('3OHT', () => {
  

  beforeEach(async () => {
    
    [owner] = await ethers.getSigners();
    console.log("Deploying contracts with the account:", owner.address);    
    console.log("Account balance:", (await owner.getBalance()).toString());
    const DemoToken = await ethers.getContractFactory("ThreeOhToken");
    demoToken = await DemoToken.deploy();
    console.log("Contract deployed at:", demoToken.address);
    [owner, addr1, addr2, ...addrs] = await ethers.getSigners();

  });

  it("Should should successfully deploy and balance and supply check", async () => {
    
    console.log("success!");
    const ownerBalance=await demoToken.balanceOf(owner.address);   
    console.log("owner Balance"+ownerBalance);  
    let totalSupply=await demoToken.totalSupply();
    console.log("TSUP"+totalSupply.toString());
    expect(totalSupply.toString()).to.equal(ownerBalance.toString());
  });

  it("Should transfer tokens between accounts", async () => {

    await demoToken.transfer(addr1.address, 100);
    const addr1Bal = await demoToken.balanceOf(addr1.address);
    expect(addr1Bal).to.equal(100);
  });

  it("shold allow other account to spent amount", async () =>{

    const appr = await demoToken.approve(addr1.address,100000);
    const allowAmt = await demoToken.allowance( owner.address, addr1.address);
    console.log("allowence amount",allowAmt.toString());
    expect(allowAmt).to.equal(100000);
    
  }); 

  
});