
async function main() {
    const ThreeOhToken_1 = await ethers.getContractFactory("ThreeOhToken_1");
    console.log("Deploying ThreeOhToken_1...");
    const threeOhToken_1 = await upgrades.deployProxy(ThreeOhToken_1,{ initializer: 'initialize' });
    console.log("ThreeOhToken_1 deployed to:", threeOhToken_1.address);
  }
  
  main()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    });