const { expect } = require('chai');
//const { ethers } = require('ethers');
 
let demoToken;
let owner;// = "0x54c3ecf2aBBD2e48869619742690327fA492DB1f";
let addr1;// = "0x08af9fa599df374c2aE6F354Cd02027d86bd8eD0";
let addr2;// = "0x8c2b9Bd235BF5d2eb968c08b9fBac367D3D4a616";
 
// Start test block
describe('3OHT', function () {
  

  beforeEach(async function() {
    const DemoToken = await ethers.getContractFactory("ThreeOhToken_2");

    demoToken = await DemoToken.deploy();
    await demoToken.deployed();
    console.log(await ethers.getSigners());
    [owner, addr1, addr2] = await ethers.getSigners();

  });
  
  it("Should should successfully deploy", async function () {
   console.log("success!");
  });

  it("Should have hame ThreeOh Token_1", async function() {
    const name = await demoToken.name();
    console.log(name);

    expect(name == "ThreeOh Token_1");
  });

  it("Should have total supply of 21T", async function() {
    const ts = await demoToken.totalSupply();
    console.log(ts.toString());

   // expect(name == "ThreeOh Token_1");
  });
});