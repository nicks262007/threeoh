// scripts/deploy.js
async function main() {
    const ThreeOhToken = await ethers.getContractFactory("ThreeOhToken");
    console.log("Deploying ThreeOhToken...");
    const threeOhToken = await upgrades.deployProxy(ThreeOhToken,{ initializer: 'initialize' });
    console.log("ThreeOhToken deployed to:", threeOhToken.address);
  }
  
  main()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    });